from geopy.geocoders import Nominatim

nom = Nominatim(user_agent="gis_books", timeout=100)